<?php
$servername = "localhost";
$username = "root";
$password = "root";
$dbname = "onlineevents";
$conn = mysqli_connect($servername, $username, $password, $dbname);
?>